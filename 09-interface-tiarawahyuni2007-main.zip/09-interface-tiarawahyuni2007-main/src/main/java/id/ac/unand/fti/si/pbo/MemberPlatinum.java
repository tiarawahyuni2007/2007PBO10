package id.ac.unand.fti.si.pbo;

public class MemberPlatinum {
    
}
