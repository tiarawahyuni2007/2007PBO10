package id.ac.unand.fti.si.pbo;

public class App {
    
    public static void main(String[] args) {
    }
    
}
